import java.util.List;

public class DefenderArcade {
  
  public int countArcades(List<String> times) {
    int arcadeTotal = 0;
    int temp = 0;
    
    for (int i = 0; i < times.size(); i++) {
        String[] currentPlayer = times.get(i).split(" ");
        temp = 0;
        for (int j = 0; j < times.size(); j++) {
            String[] nextPlayer = times.get(j).split(" ");
            if ((Integer.valueOf(currentPlayer[0]) >= Integer.valueOf(nextPlayer[0]) && Integer.valueOf(currentPlayer[0]) < Integer.valueOf(nextPlayer[1]))
                || (Integer.valueOf(currentPlayer[1]) > Integer.valueOf(nextPlayer[0]) && Integer.valueOf(currentPlayer[1]) <= Integer.valueOf(nextPlayer[1]))) {
                temp++;
            }
        }
        
        arcadeTotal = temp > arcadeTotal ? temp : arcadeTotal;
    }
    
    return arcadeTotal;
  }
}
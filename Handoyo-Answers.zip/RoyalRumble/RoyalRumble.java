import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RoyalRumble {
  
  private Map<String, Integer> romanLibs = new HashMap();

  public List<String> getSortedList(List<String> names) {
      generateRoman();
      romanToNumber(names);
      Collections.sort(names, new Comparator<String>() {
          @Override
          public int compare(String o1, String o2) {
              String[] sp1 = o1.split(" ");
              String[] sp2 = o2.split(" ");
              return sp1[0].compareTo(sp2[0]) + Integer.valueOf(sp1[1]).compareTo(Integer.valueOf(sp2[1]));
          }
      });
      numberToRoman(names);
      return names;
  }

  private void generateRoman() {
      String[] underTen = new String[]{"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX"};
      String[] times = new String[]{"", "X", "XX", "XXX", "XL", "L"};
      for (int i = 1; i <= 50; i++) {
          String a = String.valueOf(i);
          String val = "";
          if (a.length() < 2) {
              val = times[0] + underTen[i];
          } else {
              val = times[Integer.valueOf(String.valueOf(a.charAt(0)))] + underTen[Integer.valueOf(String.valueOf(a.charAt(1)))];
          }
          romanLibs.put(val, i);
      }
  }

  private void romanToNumber(List<String> names) {
      for (int i = 0; i < names.size(); i++) {
          String[] sp = names.get(i).split(" ");
          names.set(i, sp[0].concat(" ").concat(romanLibs.get(sp[1]).toString()));
      }
  }

  private void numberToRoman(List<String> names) {
      for (int i = 0; i < names.size(); i++) {
          String[] sp = names.get(i).split(" ");
          for (Map.Entry<String, Integer> entry : romanLibs.entrySet()) {
              if (entry.getValue().equals(Integer.valueOf(sp[1]))) {
                  names.set(i, sp[0].concat(" ").concat(entry.getKey()));
                  break;
              }
          }
      }
  }
}
